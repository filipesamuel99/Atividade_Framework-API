<?php
	echo "Hello World";
?>	